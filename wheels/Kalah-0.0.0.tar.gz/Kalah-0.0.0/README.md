[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/AleksandrShvartz/StrategyDSL-lab/main.svg)](https://results.pre-commit.ci/latest/github/AleksandrShvartz/StrategyDSL-lab/main)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)


# discr-game-lab

Discrete game Laboratory work system

This repository contains
  - email-bot (which can take files with extension *.py from message and place them with good name in another dicrectory)
  - check-bot (which use some metaprogramming magic to run one program with different functions, which were saved by email-bot)

As for libraries I used https://github.com/ianovir/emailpy repo, but it was too hard for me to install it in right way, so I just places it here and made some improvments.

I think this code is pretty neat so please, star it.
